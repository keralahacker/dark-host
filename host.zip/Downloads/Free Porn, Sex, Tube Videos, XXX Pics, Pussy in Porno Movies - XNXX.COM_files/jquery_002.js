
define([], function() { return window.jQuery; });